"""
self

A python package for interfacing with the Spectral Element Library in Fortran (https://github.com/fluidnumerics/SELF).
"""

__version__ = "0.0.0"
__author__ = "Dr. Joe Schoonover"
__credits__ = "Fluid Numerics LLC"
