# SELF for Python
This package allows you to interface with the Spectral Element Library in Fortran from Python, giving you flexibility in designing solvers and simulations that can be accelerated by GPU and multi-GPU platforms. 
